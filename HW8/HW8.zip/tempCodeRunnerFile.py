one:
        date_of_birth = customer.date_of_birth
    if education is None:
        education = customer.education
    if address is None:
        address = customer.address